/*
 * This is present in order to correct a JOGL bug.
 * https://forum.jogamp.org/Crash-in-WindowsAWTWGLGraphicsConfigurationFactory-td4040703.html
 *  */
package jogamp.opengl.windows.wgl.awt;