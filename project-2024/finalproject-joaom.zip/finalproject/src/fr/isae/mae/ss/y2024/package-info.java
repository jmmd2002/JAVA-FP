/**
 * Please create a subpackage with the name of the application in it, and there you can create your application.
 */
package fr.isae.mae.ss.y2024;